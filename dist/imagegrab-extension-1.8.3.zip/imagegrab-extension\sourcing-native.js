// Runs in the platform page; uses its rendered image-upload input, without private endpoints.
async function upload1688Reference(dataUrl) {
  if (!/^data:image\/jpeg;base64,/.test(dataUrl) || dataUrl.length>4*1024*1024) return {ok:false,error:'参考图片无效或过大'};
  let input=[...document.querySelectorAll('input[type="file"]')].find(x=>/image|\.png|\.jpg|\.jpeg/.test(x.accept)&&!x.disabled);
  if(!input){
    const control=[...document.querySelectorAll('[title],[aria-label],button,[role="button"]')].find(x=>/图片搜索|以图搜|识图搜索/.test(`${x.title||''} ${x.getAttribute('aria-label')||''} ${x.innerText||''}`)&&x.getBoundingClientRect().width>0);
    if(control){control.click();await new Promise(r=>setTimeout(r,500));input=[...document.querySelectorAll('input[type="file"]')].find(x=>/image|\.png|\.jpg|\.jpeg/.test(x.accept)&&!x.disabled);}
  }
  if(!input)return {ok:false,error:'当前页面未找到平台图片上传入口。请点击1688的相机按钮上传参考图，完成后回本页读取候选。'};
  const blob=await (await fetch(dataUrl)).blob(),transfer=new DataTransfer();
  transfer.items.add(new File([blob],'imagegrab-reference.jpg',{type:'image/jpeg'}));
  input.files=transfer.files;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  return {ok:true,message:'已向1688原生图片上传框提交参考图；请在1688检查上传结果与框选主体，再回来读取候选。'};
}
