(() => {
  'use strict';
  const text = node => (node?.innerText || '').replace(/\s+/g, ' ').trim();
  const all = (root, selector) => root ? [...root.querySelectorAll(selector)] : [];
  const unique = values => [...new Set(values.filter(Boolean))];
  function http(value) { if (!value) return ''; try { const u = new URL(value, location.href); return /^https?:$/.test(u.protocol) ? u.href : ''; } catch { return ''; } }
  function canonical(value) { const match = String(value || '').match(/(?:detail|offer)\.1688\.com\/offer\/(\d+)\.html/); return match ? `https://detail.1688.com/offer/${match[1]}.html` : http(value); }
  function imageKey(value) { return value.replace(/\.(jpg|png|jpeg)(?:_[^/?]*)?(?:\?[^#]*)?$/i, '.$1'); }
  function variantKey(value) {
    try {
      const url = new URL(value, location.href);
      return url.pathname.replace(/(?:_sum\.(?:jpe?g|png|webp)|_\.(?:jpe?g|png|webp))$/i, '').toLowerCase();
    } catch { return ''; }
  }
  function imageInfo(img) {
    const url = http(img?.currentSrc || img?.getAttribute('src') || img?.dataset?.src || img?.dataset?.original || '');
    if (!url) return null;
    return { url, width: Number(img.naturalWidth) || 0, height: Number(img.naturalHeight) || 0 };
  }
  function bestLoadedVariant(sourceUrl) {
    const key = variantKey(sourceUrl);
    if (!key) return { url: sourceUrl, thumbnailUrl: '', width: 0, height: 0 };
    const candidates = all(document, '#gallery img.preview-img, .od-gallery-preview img.preview-img')
      .map(imageInfo).filter(item => item && variantKey(item.url) === key);
    const source = { url: sourceUrl, thumbnailUrl: '', width: 0, height: 0 };
    const best = candidates
      .filter(item => item.url !== sourceUrl && (item.width * item.height > 0 || /_\.(?:jpe?g|png|webp)(?:[?#]|$)/i.test(item.url)))
      .sort((a, b) => (b.width * b.height) - (a.width * a.height))[0];
    return best ? { url: best.url, thumbnailUrl: sourceUrl, width: best.width, height: best.height } : source;
  }
  function images(root, selector, role) {
    const seen = new Set();
    return all(root, selector).flatMap(img => {
      const link = img.closest('a[href]');
      if (link && /\/offer\/\d+/.test(link.href) && canonical(link.href) !== canonical(location.href)) return [];
      const raw = imageInfo(img);
      if (!raw || /(?:placeholder|loading|sprite|avatar|logo)/i.test(raw.url) || seen.has(imageKey(raw.url))) return [];
      seen.add(imageKey(raw.url));
      const variant = role === 'sku-option' ? bestLoadedVariant(raw.url) : { url: raw.url, thumbnailUrl: '', width: raw.width, height: raw.height };
      return [{ url: variant.url, thumbnailUrl: variant.thumbnailUrl, width: variant.width || raw.width, height: variant.height || raw.height, role, sourceUrl: canonical(location.href) }];
    });
  }
  function shadowRoots(root) {
    if (!root) return [];
    return [root, ...all(root, '*').filter(el => el.shadowRoot).flatMap(el => shadowRoots(el.shadowRoot))];
  }
  function customerService(url, capturedAt) {
    const offerId = url.match(/\/offer\/(\d+)/)?.[1] || '';
    const missing = { status: 'not-found', url: '', loginId: '', memberId: '', sourceUrl: url, capturedAt };
    // Read only the page's serialized public seller data. Content scripts cannot
    // access page-world globals; do not execute the site's inline JavaScript.
    for (const script of all(document, 'script:not([src])')) {
      const raw = script.textContent || '';
      if (!raw.includes('window.context=') && !/window\.context\s*=/.test(raw)) continue;
      const marker = /\}\)\s*\(\s*window\.contextPath\s*,\s*/.exec(raw);
      if (!marker) continue;
      try {
        // The full initializer contains JavaScript numeric keys (skuWeight),
        // so JSON.parse on the whole initializer fails on real pages. Extract
        // only the small public seller objects, ignoring keys inside strings.
        const objects = new Map(['frontSellerMemberModel', 'offerBaseInfo', 'sellerModel', 'offerDetail'].map(key => [key, []]));
        function stringEnd(start) {
          let index = start + 1;
          for (; index < raw.length; index++) {
            if (raw[index] === '\\') { index++; continue; }
            if (raw[index] === '"') return index + 1;
          }
          return raw.length;
        }
        for (let index = marker.index + marker[0].length; index < raw.length; index++) {
          if (raw[index] !== '"') continue;
          const end = stringEnd(index), key = raw.slice(index + 1, end - 1);
          index = end - 1;
          if (!objects.has(key)) continue;
          const after = /^\s*:\s*\{/.exec(raw.slice(end));
          if (!after) continue;
          const start = end + after[0].length - 1;
          let cursor = start + 1, depth = 1;
          for (; cursor < raw.length && depth; cursor++) {
            if (raw[cursor] === '"') { cursor = stringEnd(cursor) - 1; continue; }
            if (raw[cursor] === '{') depth++;
            if (raw[cursor] === '}') depth--;
          }
          try { objects.get(key).push(JSON.parse(raw.slice(start, cursor))); } catch { /* Skip unsupported fragments. */ }
        }
        const base = objects.get('offerBaseInfo').find(value => String(value.offerId || '') === offerId);
        const detail = objects.get('offerDetail').find(value => String(value.offerId || '') === offerId);
        if (!base && !detail) continue;
        const fronts = objects.get('frontSellerMemberModel');
        const front = fronts.find(value => String(value.frontOfferId || '') === offerId);
        if (fronts.some(value => value.frontSellerLoginId) && !front) continue;
        const sellers = objects.get('sellerModel');
        const seller = sellers.length === 1 ? sellers[0] : null;
        const loginId = front?.frontSellerLoginId || base?.sellerLoginId || seller?.loginId;
        const memberId = front?.frontSellerLoginId ? front.frontSellerMemberId : base?.sellerLoginId ? base.sellerMemberId : seller?.memberId;
        if (typeof loginId !== 'string' || !loginId.trim()) continue;
        const link = new URL('https://air.1688.com/app/ocms-fusion-components-1688/def_cbu_web_im/index.html');
        link.searchParams.set('touid', `cnalichn${loginId}`);
        link.searchParams.set('siteid', 'cnalichn');
        link.searchParams.set('offerId', offerId);
        return { status: 'available', url: link.href, loginId, memberId: typeof memberId === 'string' ? memberId : '', offerId, source: 'page-context-seller', method: 'platform-web-im-route', sourceUrl: url, capturedAt };
      } catch { /* An unsupported page template must not stop SKU collection. */ }
    }
    return missing;
  }
  function collect() {
    const title = text(document.querySelector('#productTitle .title-content h1'));
    if (!title) throw new Error('未识别当前商品详情模板；请等待商品标题加载');
    const url = canonical(location.href), capturedAt = Date.now();
    const attributes = [], seen = new Set();
    const add = (name, value) => { if (name && value && !seen.has(`${name}\0${value}`)) { seen.add(`${name}\0${value}`); attributes.push({ name, value }); } };
    all(document, '#productAttributes .cpv-attr-item').forEach(el => add(text(el.querySelector('.cpv-attr-label')), text(el.querySelector('.cpv-attr-value'))));
    all(document, '#productAttributes th.ant-descriptions-item-label').forEach(el => add(text(el), text(el.nextElementSibling)));
    const attr = label => attributes.find(a => a.name === label)?.value || '';
    const supplier = document.querySelector('#shopNavigation a.shop-company-name');
    const mainImages = images(document.querySelector('#gallery'), 'img.preview-img', 'main');
    const descriptionImages = shadowRoots(document.querySelector('#description')).flatMap(root => images(root, 'img', 'description'));
    const optionImages = images(document.querySelector('#skuSelection'), '.sku-filter-button img, .expand-view-item img', 'sku-option');
    const media = [...mainImages, ...descriptionImages, ...optionImages].filter((item, i, list) => list.findIndex(x => x.url === item.url && x.role === item.role) === i);
    const groups = all(document, '#skuSelection .feature-item');
    const selectedOptions = groups.flatMap(group => all(group, '.sku-filter-button.active').map(button => {
      const image = images(button, 'img', 'sku-option')[0];
      return { group: text(group.querySelector('h3')), value: text(button.querySelector('.label-name')) || text(button), imageUrl: image?.url || '', thumbnailUrl: image?.thumbnailUrl || '', imageWidth: image?.width || 0, imageHeight: image?.height || 0 };
    }));
    const skus = groups.flatMap(group => all(group, '.expand-view-item').map(row => {
      const rowImage = images(row, 'img', 'sku-option')[0];
      const selectedImage = selectedOptions.find(o => o.imageUrl);
      return {
      group: text(group.querySelector('h3')), value: row.querySelector('.item-label')?.getAttribute('title') || text(row.querySelector('.item-label')) || (group.classList.contains('pseudo') ? '默认规格（页面未列名称）' : ''),
      priceText: all(row, '.item-price-stock').map(text).find(v => /[¥￥]/.test(v)) || '',
      stockText: all(row, '.item-price-stock').map(text).find(v => /库存/.test(v)) || text(row.querySelector('.item-count-invalid')),
      selectedOptions, imageUrl: rowImage?.url || selectedImage?.imageUrl || '', thumbnailUrl: rowImage?.thumbnailUrl || selectedImage?.thumbnailUrl || '', imageWidth: rowImage?.width || selectedImage?.imageWidth || 0, imageHeight: rowImage?.height || selectedImage?.imageHeight || 0, imageAssociation: rowImage ? 'sku-row' : selectedImage ? 'selected-option-shared' : 'not-found'
    };}).filter(row => row.value));
    const salesObservations = unique(all(document, '#mainPrice .sold-count .slick-slide:not(.slick-cloned)').map(text)).map(value => ({ text: value, metric: 'detail-displayed-sales', sourceUrl: url, capturedAt }));
    const priceText = text(document.querySelector('#mainPrice .price-info')).replace(/\s+/g, '');
    const priceContext = text(document.querySelector('#mainPrice .old-customer-tag'));
    const moqText = text(document.querySelector('#mainPrice .price-component p')).match(/\d[\d,.]*\s*(?:件|个|套|箱|包|米|千克|公斤)\s*起批/)?.[0] || '';
    const supplierMetrics = all(document, '#shopNavigation .shop-data-item').map(el => ({ name: text(el.querySelector('.shop-data-item-label')), value: text(el.querySelector('.shop-data-item-value')) })).filter(x => x.name && x.value);
    const packaging = all(document, '#productPackInfo table').map(table => ({ headers: all(table, 'th').map(text), rows: all(table, 'tbody tr').map(row => all(row, 'td').map(text)) }));
    return {
      captureKind: 'detail', offerId: url.match(/\/offer\/(\d+)/)?.[1] || '', title, url,
      brand: attr('品牌'), category: attr('类别'), origin: attr('产地'), attributes,
      supplierName: text(supplier), supplierUrl: http(supplier?.href || ''), supplierMetrics,
      customerService: customerService(url, capturedAt),
      supplierYears: text(document.querySelector('#shopNavigation .shop-tp-year')),
      supplierCategory: text(document.querySelector('#shopNavigation .shop-category-name')), supplierRating: text(document.querySelector('#shopNavigation .shop-star-text')),
      shipFrom: text(document.querySelector('#shippingServices .location')),
      priceText, priceContext, moqText, salesText: salesObservations[0]?.text || '', salesObservations,
      skus, selectedOptions, media, packaging, promotionText: text(document.querySelector('#productPromotion')), images: unique(media.map(item => item.url)),
      videoUrls: unique(shadowRoots(document.querySelector('#description')).concat(document.querySelector('#gallery')).flatMap(root => all(root, 'video').map(v => http(v.currentSrc || v.src || '')))),
      services: unique(all(document, '#mainServices .service-item-link').map(text)),
      specs: attributes.map(a => `${a.name}：${a.value}`).join('\n'),
      certificateEvidence: { status: 'not-verified', note: '仅记录页面参数；未进行官方认证核验' },
      visibleText: attributes.map(a => `${a.name}：${a.value}`).join('；'), capturedAt
    };
  }
  globalThis.ImageGrabDetail = { collect, canonical };
})();
